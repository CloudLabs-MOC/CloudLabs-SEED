
This folder stores the certificates needed by the server and proxy.
It is used by the server and proxy containers. 
