
When the containers are started, this folder will be mounted 
to all the containers, so the contents in this folder are 
accessible from the containers. This makes it more convenient 
to do the lab tasks. 
