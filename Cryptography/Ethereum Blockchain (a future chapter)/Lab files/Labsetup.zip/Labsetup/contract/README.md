# Solidity

The solidity 0.6.8 is downloaded from the following site: 
https://github.com/ethereum/solidity/releases/download/v0.6.8/solc-static-linux
