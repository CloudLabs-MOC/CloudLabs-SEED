#!/bin/bash 

declare -a names=("as155r" "as180r" "as171r" \
                  "as2r-r105" "as3r-r105")

source ../utilities/upload.sh
