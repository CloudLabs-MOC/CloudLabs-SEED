# Lab Setup

## Python Code

Students can run the python code to generate the 
Internet emulator. The results are stored in 
the `output` folder. 

## Container Files

The container files are stored in the 
`output` folder. 

