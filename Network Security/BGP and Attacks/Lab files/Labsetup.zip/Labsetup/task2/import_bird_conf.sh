#!/bin/bash 

declare -a names=("as153r" "as160r" "as171r" \
                  "as5r-r101" "as5r-r103" "as5r-r105" "as3r-r103")

source ../utilities/download.sh
