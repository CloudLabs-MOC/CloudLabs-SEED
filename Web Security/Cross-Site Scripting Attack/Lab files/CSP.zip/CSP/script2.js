document.getElementById('area5').innerHTML = "OK";
