document.getElementById('area4').innerHTML = "OK";
