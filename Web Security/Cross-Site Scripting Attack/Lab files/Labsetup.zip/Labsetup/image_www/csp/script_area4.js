document.getElementById('area4').innerHTML = "<font color='green'>OK</font>";
